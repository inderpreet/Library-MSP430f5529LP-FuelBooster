Tiva C series software --integrate the project in Tiva C library, you just need to put the project file into the Tiva C installation file to build and test.
