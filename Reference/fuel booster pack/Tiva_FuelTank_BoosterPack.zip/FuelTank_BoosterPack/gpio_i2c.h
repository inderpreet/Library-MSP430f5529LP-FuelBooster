#ifndef	GPIO_I2C_H
#define	GPIO_I2C_H


#define SCL	0x40	//PB.6
#define SDA	0x80	//PB.7

#define NACK 0
#define ACK  1

#define READ	0x01
#define WRITE	0x00

#define	BIT0	0x00000001
#define	BIT7	0x00000080

#define SCL_1	GPIO_PORTB_DATA_R |= 0x40
#define SCL_0	GPIO_PORTB_DATA_R &= ~(0x40)
#define SDA_1	GPIO_PORTB_DATA_R |= 0x80
#define	SDA_0	GPIO_PORTB_DATA_R &= ~(0x80)

#define SLAVE_ADDRESS 0x55

#define INPUT	0x01
#define OUTPUT	0x00

void I2CDELAY(int value);
void LM4F120_SWI2CMST_start(void);
void LM4F120_SWI2CMST_stop(void);
void ACKIIC(unsigned char RW, unsigned char LastByte);

int LM4F120_SWI2CMST_txByte(unsigned char data);
unsigned char LM4F120_SWI2CMST_rxByte(char );
int LM4F120_SWI2CMST_writeBlock(unsigned char SlaveAddress,
								unsigned int numBytes, unsigned char multi,
								void* TxData);
int LM4F120_SWI2CMST_readBlock(unsigned char SlaveAddress,
										unsigned int numBytes, void* RxData);


#endif
