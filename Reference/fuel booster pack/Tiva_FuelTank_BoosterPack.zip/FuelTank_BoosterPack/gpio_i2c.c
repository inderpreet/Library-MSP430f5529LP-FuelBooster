/**
  ******************************************************************************
  * @file    gpio_i2c.c
  * @date    10-October-2013
  * @brief   This file provides all the I2C  functions.
  */


/*
******************************************************************************
*                                  INCLUDE FILES
******************************************************************************
*/
#include "gpio_i2c.h"
#include "inc/tm4c1233h6pm.h"
#include <stdbool.h>
#include <stdint.h>


/*
******************************************************************************
*                                  FUNCTION DEFINITIONS
******************************************************************************
*/

/**
  * @brief  Delay some times
  * @param  int value
  * @retval None
  */
void I2CDELAY(int value)
{
	int i;
	for(i = 0; i < value; i++)
	{
		GPIO_PORTF_DATA_R |= 0x08;

	}

	for(i = 0; i < value; i++)
	{
		GPIO_PORTF_DATA_R &= ~(0x08);

	}

}

/**
  * @brief  generate start signal
  * @param
  * @retval None
  */
void LM4F120_SWI2CMST_start(void)
{
	SDA_1;                                    
	SCL_1;                                    
	I2CDELAY(0x25);                                 
	SDA_0;                                    
	I2CDELAY(0x25);                                 
	SCL_0;                                    
	I2CDELAY(0x25);                                 
}

/**
  * @brief   generate stop signal
  * @param
  * @retval None
  */
void LM4F120_SWI2CMST_stop(void)
{
	GPIO_PORTB_DIR_R = SCL | SDA;
	SDA_0;                                    
	I2CDELAY(40);
	SCL_1;                                    
	I2CDELAY(40);                                 
	SDA_1;                                    
	I2CDELAY(40);                                 
}

/**
  * @brief	config SDA direction
  * @param	unsigned char dir
  * @retval None
  */
void SDA_DIR(unsigned char dir)
{
	if(dir == INPUT)
	{
		GPIO_PORTB_DIR_R |= SCL;
		GPIO_PORTB_DIR_R &= ~SDA;
	}
	else
	{
		GPIO_PORTB_DIR_R |= SCL;
		GPIO_PORTB_DIR_R |= SDA;

	}
}

/**
  * @brief   wait ACK from receiver
  * @param
  * @retval  0 : Get Ack from slave device
  *         -1 : Get Ack timeout
  */
int IICWaitAck(void)
{
	unsigned char ucOverTime = 0;
	I2CDELAY(15);
	SDA_1;
	GPIO_PORTB_DIR_R &= ~SDA;
	I2CDELAY(10);
	SCL_1;
	while(GPIO_PORTB_DATA_R & SDA)
	{
		ucOverTime++;
		if(ucOverTime > 250)
		{
			LM4F120_SWI2CMST_stop();
			return -1;
		}
	}
	GPIO_PORTB_DIR_R |= SDA;
	I2CDELAY(40);
	SCL_0;
	return 0;
}

/**
  * @brief   generate ack signal
  * @param
  * @retval None
  */
void IICAck(void)
{
	SDA_DIR(WRITE);
	SDA_0;
	SCL_1;
	I2CDELAY(40);
	SCL_0;
	SDA_1;
}

/**
  * @brief	master transmit a byte
  * @param  unsigned char data
  * @retval  0 : transmit successfully
  *         -1 : transmit failed, no Ack respond
  */
/* master transmit a byte */
int LM4F120_SWI2CMST_txByte(unsigned char data)
{
	unsigned char bits, temp;
	int ret = 0;
	SCL_0;                                    
	temp = data;                             
	bits = 0x08;                             
	//
	// Loop until all bits are shifted
	//
	while (bits != 0x00)                      
	{
		I2CDELAY(20);
		if (temp & BIT7)                        
			SDA_1;                               
		else
			SDA_0 ;                              
		I2CDELAY(20);                              
		SCL_1;                                 
		I2CDELAY(40);                              
		temp = (temp << 1);                     
		SCL_0;                                  
		bits = (bits - 1);                      
	}
	//
	// wait ack from slave
	//
	ret = IICWaitAck();

	I2CDELAY(4000);							

    return ret;
}

/**
  * @brief	master receive a byte from slave
  * @param  char ack
  * @retval 8-bit data byte
  */
unsigned char LM4F120_SWI2CMST_rxByte(char ack)
{
	unsigned char bits, data = 0;

	SDA_1;                                    
	GPIO_PORTB_DIR_R &= ~(SDA);
	//
	// Load I2C bit counter
	//
	bits = 0x08;              
	//
	// Loop until all bits are read
	//
	while (bits > 0)                          
	{
		SCL_1;              
		//
		// Wait for any SCL clock stretching
		//
		while ((GPIO_PORTB_DATA_R & SCL) == 0); 
		I2CDELAY(40);         
		//
		// Shift bits 1 place to the left
		//
		data = (data << 1);            
		//
		// Check digital input
		//
		if (GPIO_PORTB_DATA_R & SDA)           
			data = (data + 1);                    
		SCL_0;                                 
		I2CDELAY(40);                              
		//
		// Decrement I2C bit counter
		//
		bits = (bits - 1);                      
	}
  	SDA_DIR(WRITE);
	//
	// Need to send ACK to Slave
	//
  	if (ack)                                 
  		SDA_0;                                 
  	else
  		SDA_1;
  	SCL_1;
  	I2CDELAY(40);
  	SCL_0;
  	SDA_1;
  	I2CDELAY(4000);
  	return (data);                           
}

/**
  * @brief	transmit multiple bytes
  * @param  unsigned char SlaveAddress,
			unsigned int numBytes,
			unsigned char multi,
			void* TxData
  * @retval  0 : writeBlock successfully
  *         -1 : writeBlock failed, no Ack respond
  */
int LM4F120_SWI2CMST_writeBlock(unsigned char SlaveAddress,
								unsigned int numBytes, unsigned char multi,
								void* TxData)
{
	unsigned int  i;
	unsigned char *temp;
	int ret;
	//
	// Initialize array pointer
	//
	temp = (unsigned char *)TxData;          
	LM4F120_SWI2CMST_start();
	ret = LM4F120_SWI2CMST_txByte((SLAVE_ADDRESS << 1) | WRITE);
	if (ret < 0)
		return ret;

	for (i = 0; i < numBytes; i++)
	{
		SDA_DIR(OUTPUT);
		//
		// Send data and ack
		//
		ret = LM4F120_SWI2CMST_txByte(*(temp));
		if (ret < 0)
			return ret;
	    temp++;                                 
	}
	//
	// Need STOP condition? Yes, send STOP condition
	// 
	if (multi == 0)                           
	{
		LM4F120_SWI2CMST_stop();                
	}

	I2CDELAY(40);

	return 0;
}

/**
  * @brief	receive multiple bytes
  * @param  unsigned char SlaveAddress,
			unsigned int numBytes,
			void* RxData
  * @retval  0 : readBlock successfully
  *         -1 : readBlock failed, no Ack respond or all data is 0
  */
int LM4F120_SWI2CMST_readBlock(unsigned char SlaveAddress,
										unsigned int numBytes, void* RxData)
{
	int  i = 0;
	int  j = 0;
	int  valid_data = 0;
	unsigned char* temp;
	int ret;
	//
	// Initialize array pointer
	//
	temp = (unsigned char *)RxData;           
	SDA_DIR(OUTPUT);
    LM4F120_SWI2CMST_start();
    ret = LM4F120_SWI2CMST_txByte((SLAVE_ADDRESS<<1) | READ);
    if(ret < 0)
    	return ret;

    for (i = 0; i < numBytes-1; i++)
    {	
		//
		// Read 8-bit data & then send ACK
		//
    	*(temp) = LM4F120_SWI2CMST_rxByte(ACK);
    	temp++;                                
    }
	//
	// Read last 8-bit data with no ACK
	//
    *(temp) = LM4F120_SWI2CMST_rxByte(NACK);
    LM4F120_SWI2CMST_stop();

    //
    // If the battery capacity is too low
    // We cannot read any data from bq27510
    // The SDA line is always 0
    // In this case, we return -1 to let main program show "charge battery"
    //
    temp = (unsigned char *)RxData;
    for (i = 0; i < numBytes-1; i++) {
    	for(j = 0; j < 8; j++) {
    		if(temp[j] != 0) {
    			valid_data = 1;
    		}
    	}
    	temp++;
    }

    if (valid_data)
    	return 0;
    else
    	return -1;
}



