//#############################################################################
//
//  File:   f2802x_examples/FuelTank_BoostPack/main.c
//
//  Title:  Fuel Tank BoosterPack Demo.
//
//  Group:          C2000
//  Target Device:  TMS320F2802x
//
//! \addtogroup example_list
//!  <h1>Fuel Tank BoosterPack Demo</h1>
//!
//
//  (C) Copyright 2012, Texas Instruments, Inc.
//#############################################################################

/*
******************************************************************************
*                                  INCLUDE FILES
******************************************************************************
*/
#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File
#include "bq27510.h"


/*
******************************************************************************
*                                  DEFINITIONS
******************************************************************************
*/
/* 
 * There is two group of GPIO can be used as I2C, configure which group used 
 * in here 
 */
#define GPIO28_29  0                                // Use GPIO 28 29 as I2C
#define GPIO32_33  1                                // Use GPIO 32 33 as I2C

#define I2C_SLAVE_ADDR      0x0055                  // Slave Address
#define I2C_NUMBYTES        2                       // byte number per r/w
#define I2C_RESET           0x0020
#define I2C_READ_ENABLE     0x2c20                  // Master Mode��Read
#define I2C_WRITE_ENABLE    0x6620                  // Master Mode��Write


/*
******************************************************************************
*                                  GLOBAL VARIABLES
******************************************************************************
*/
char RxDataBuff[20];
unsigned int timerCount = 10;
unsigned int num = 0;


/*
******************************************************************************
*                                  FUNCTION PROTOTYPES
******************************************************************************
*/
extern void printf(char *, ...);

void InitI2CGpio_BQ27510();
void I2C_BUSY();
void I2C_STOP();
void I2C_BQ27510_Init();
int Read_BQ27510(char *buffer, int num);
void Write_BQ27510(int cmd);
void I2CWriteData(char data);

void fputc(unsigned);
void fputs(char *);
void SCIAInit(void);
void SendChar(unsigned char data);
void SendString(char *msg);
char receiveByte();

void initTimer(void);
void receivestr(char *s);
interrupt void tim0_isr(void);
interrupt void i2c_int1a_isr(void);
unsigned int transBytes2Int(unsigned char msb, unsigned char lsb);



/*
******************************************************************************
*                                  FUNCTION DEFINITIONS
******************************************************************************
*/

/**
  * @brief  Main function
  * @param  None
  * @retval None
  */
void main(void)
{
    char temp;
    char str[20];
    char c = '%';
    int interval = 0;
    int i;
    int temperature, voltage;
    signed int  AverageCurrent;
    unsigned int  RemainingCapacity;
    unsigned int  soc;                          // Stores State of Charge
    unsigned int  dcap;                         // Stores Design Capacity
    unsigned int valid_data = 0;

    /* System Initialization */
    InitSysCtrl();
    InitI2CGpio_BQ27510();
    DINT;
    InitPieCtrl();
    IER = 0x0000;
    IFR = 0x0000;
    InitPieVectTable();
    EALLOW;
    PieVectTable.TINT0 = &tim0_isr;
    PieVectTable.I2CINT1A = &i2c_int1a_isr;
    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;   //Enable PIE
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;   //Enable int1.7
    IER |= 0x0001;                       //Enable GROUP1
    EINT;
    EDIS;



    // Only used if running from FLASH
    // Note that the variable FLASH is defined by the build configuration
#ifdef FLASH
    // Copy time critical code and Flash setup code to RAM
    // The  RamfuncsLoadStart, RamfuncsLoadSize, and RamfuncsRunStart
    // symbols are created by the linker. Refer to the linker files.
    memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (size_t)&RamfuncsLoadSize);

    // Call Flash Initialization to setup flash waitstates
    // This function must reside in RAM
    InitFlash();    // Call the flash wrapper init function
#endif //(FLASH)

    I2C_BQ27510_Init();
    SCIAInit();


    printf("******************************************\r\n");
    printf("This is a battery demo !                  \r\n");
    printf("Press:                                    \r\n");
    printf("1. To see the battery main parameter      \r\n");
    printf("2. To see the battery State of charge!    \r\n");
    printf("******************************************\r\n");
    printf("\r\n");
    printf("\r\n");
    printf("\r\n");
    temp = receiveByte();

    while (1) {
        if (temp == '1') {
            /*
             * start the timer
             */
            initTimer();

            while (1) {
                if (timerCount == 10) {
                	valid_data = 1;
                    /* Read temperature (units = 0.1K) */
                    I2C_BUSY();
                    Write_BQ27510(bq27510CMD_TEMP_LSB);
                    I2caRegs.I2CMDR.bit.STT = 1;
                    if (!Read_BQ27510(RxDataBuff, 2)){
                    	I2caRegs.I2CMDR.bit.STP = 1;
                    	/* Convert K to Celsius degree */
                    	temperature = (transBytes2Int(RxDataBuff[1], RxDataBuff[0])) / 10 - 273;
                    } else {
                    	valid_data = 0;
                    }
                    I2caRegs.I2CMDR.bit.STP = 1;

                    /* Read AverageCurrent (units = mA) */
                    I2C_BUSY();
                    Write_BQ27510(bq27510CMD_AI_LSB);
                    I2caRegs.I2CMDR.bit.STT = 1;
                    if (!Read_BQ27510(RxDataBuff, 2)){
                    	I2caRegs.I2CMDR.bit.STP = 1;
                    	AverageCurrent = transBytes2Int(RxDataBuff[1], RxDataBuff[0]);
                    } else {
                    	valid_data = 0;
                    }
                    I2caRegs.I2CMDR.bit.STP = 1;

                    /* Read voltage (units = mV) */
                    I2C_BUSY();
                    Write_BQ27510(bq27510CMD_VOLT_LSB);
                    I2caRegs.I2CMDR.bit.STT = 1;
                    if (!Read_BQ27510(RxDataBuff, 2)){
                    	I2caRegs.I2CMDR.bit.STP = 1;
                    	voltage = transBytes2Int(RxDataBuff[1], RxDataBuff[0]);
                    } else {
                    	valid_data = 0;
                    }
                    I2caRegs.I2CMDR.bit.STP = 1;

                    /* Read state of charge (units = %) */
                    I2C_BUSY();
                    Write_BQ27510(bq27510CMD_SOC_LSB);
                    I2caRegs.I2CMDR.bit.STT = 1;
                    if (!Read_BQ27510(RxDataBuff, 2)){
                    	I2caRegs.I2CMDR.bit.STP = 1;
                    	soc = transBytes2Int(RxDataBuff[1], RxDataBuff[0]);
                    } else {
                    	valid_data = 0;
                    }
                    I2caRegs.I2CMDR.bit.STP = 1;

                    /* Read DesignCapacity (units = mAH) */
                    I2C_BUSY();
                    Write_BQ27510(0x2e);
                    I2caRegs.I2CMDR.bit.STT = 1;
                    if (!Read_BQ27510(RxDataBuff, 2)){
                    	I2caRegs.I2CMDR.bit.STP = 1;
                    	dcap = transBytes2Int(RxDataBuff[1], RxDataBuff[0]);
                    } else {
                    	valid_data = 0;
                    }
                    I2caRegs.I2CMDR.bit.STP = 1;

                    /* Read RemainingCapacity (units = mAH) */
                    I2C_BUSY();
                    Write_BQ27510(bq27510CMD_RM_LSB);
                    I2caRegs.I2CMDR.bit.STT = 1;
                    if (!Read_BQ27510(RxDataBuff, 2)){
                    	I2caRegs.I2CMDR.bit.STP = 1;
                    	RemainingCapacity  = transBytes2Int(RxDataBuff[1], RxDataBuff[0]);
                    } else {
                    	valid_data = 0;
                    }
                    I2caRegs.I2CMDR.bit.STP = 1;

                    printf("\033[2J");
                    printf("\033[H");
                    timerCount = 0;
                    if(valid_data && (soc > 10)){
                    	if (AverageCurrent > 0) {
                    		printf("The battery is charging!\r\n");
                    	} else {
                    		printf("The battery is discharging!\r\n");
                    	}

                    	printf("Current Temperature  :%d��\r\n", temperature);
                    	printf("AverageCurrent  :%dmA\r\n", AverageCurrent);
                    	printf("Current Voltage  :%dmV\r\n", voltage);
                    	printf("State of Charge :%d", soc);
                    	printf("%c\r\n", c);
                    	printf("DesignCapacity :%dmAH\r\n", dcap);
                    	printf("RemainingCapacity :%dmAH\r\n", RemainingCapacity);
                    } else {
                    	printf("There is no battery or the battery's capacity is too low\n\r");
                    	printf("Please plugin a battery or charge the battery\n\r");
                    }
                }//end if
            }//end while
        }//end if

        if (temp == '2') {
        	printf("Please set the show time interval(units = s)\r\n");
            receivestr(str);

            /*
             * convert the string into int
             */
            for (i = 0; str[i] != '\r'; i++) {
            	interval = interval * 10 + str[i] - '0';
            }//end for

            /*
             * star the timer
             */
            initTimer();
            printf("\r\n");
            timerCount = interval * 2;

            while (1) {
            	valid_data = 1;
                /*
                 * Show the state of charge every interval*2*0.5s
                 */
                if (timerCount == interval * 2) {
                    timerCount = 0;

                    /*Read state of charge (units = %)*/
                    I2C_BUSY();
                    Write_BQ27510(bq27510CMD_SOC_LSB);
                    I2caRegs.I2CMDR.bit.STT = 1;
                    if (!Read_BQ27510(RxDataBuff, 2)){
                    	I2caRegs.I2CMDR.bit.STP = 1;
                    	soc = transBytes2Int(RxDataBuff[1], RxDataBuff[0]);
                    } else {
                    	valid_data = 0;
                    }
                    I2caRegs.I2CMDR.bit.STP = 1;

                    if (valid_data && (soc>10)){
                    	printf("State of Charge :%d", soc);
                    	printf("%c\r\n", c);
                    }else {
                    	printf("There is no battery or the battery's capacity is too low\n\r");
                    	printf("Please plugin a battery or charge the battery\n\r");
                    }
                }//end if
            }//end while
        }//end if
    }//end while
}//end main


/**
  * @brief  Translate two bytes into an integer
  * @param
  * @retval The calculation results
  */
unsigned int transBytes2Int(unsigned char msb, unsigned char lsb)
{
    unsigned int tmp;

    tmp = ((msb << 8) & 0xFF00);
    return ((unsigned int)(tmp + lsb) & 0x0000FFFF);
}


/**
  * @brief  Initialize I2C GPIO pins
  * @param  None
  * @retval None
  */
void InitI2CGpio_BQ27510()
{
    EALLOW;
    /* Use GPIO28 29 as I2C */
#if GPIO28_29
    GpioCtrlRegs.GPAPUD.bit.GPIO28 = 0;
    GpioCtrlRegs.GPAPUD.bit.GPIO29 = 0;

    GpioCtrlRegs.GPAQSEL2.bit.GPIO28 = 3;
    GpioCtrlRegs.GPAQSEL2.bit.GPIO29 = 3;

    GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 2;
    GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 2;
#endif

    /* Use GPIO32 33 as I2C */
#if GPIO32_33
    GpioCtrlRegs.GPBPUD.bit.GPIO32 = 0;
    GpioCtrlRegs.GPBPUD.bit.GPIO33 = 0;

    GpioCtrlRegs.GPBQSEL1.bit.GPIO32 = 3;
    GpioCtrlRegs.GPBQSEL1.bit.GPIO33 = 3;

    GpioCtrlRegs.GPBMUX1.bit.GPIO32 = 1;
    GpioCtrlRegs.GPBMUX1.bit.GPIO33 = 1;

    GpioCtrlRegs.GPBMUX1.bit.GPIO34 = 0;  // Select GPIO34 as normal IO mode
    GpioCtrlRegs.GPBDIR.bit.GPIO34 = 1;   // Output direction
    GpioCtrlRegs.GPBPUD.bit.GPIO34 = 1;   // Pull down
#endif
    EDIS;
}


/**
  * @brief  I2C Initialization
  * @param
  * @retval None
  */
void I2C_BQ27510_Init()
{
    I2caRegs.I2CSAR = I2C_SLAVE_ADDR;	// Slave Address
    I2caRegs.I2CPSC.all = 6;            // I2C main clock prescale
    I2caRegs.I2CCLKL = 10;
    I2caRegs.I2CCLKH = 5;
    I2caRegs.I2CMDR.all = I2C_RESET;    // Reset I2C
    return;
}


/**
  * @brief  Wait while i2c bus is busy
  * @param
  * @retval None
  */
void I2C_BUSY()
{
    while (I2caRegs.I2CSTR.bit.BB == 1);
}


/**
  * @brief  Wait while i2c bus is stop
  * @param
  * @retval None
  */
void I2C_STOP()
{
    while (I2caRegs.I2CMDR.bit.STP == 1);
}


/**
  * @brief  Read data from bq27510 through i2c bus
  * @param
  * @retval 0  ��Operation normal
  * 		-1   ��Could not read data
  */
int Read_BQ27510(char *buffer, int num)
{
    char *PRxData;
    int i=0;
    I2caRegs.I2CCNT = 2;
    PRxData = buffer;
    I2caRegs.I2CMDR.all = I2C_READ_ENABLE;        // Read Enable

    /* Read data from Receive Register */
    while (num > 0) {
       	for (i=0; i<1000; i++) {
       		if (I2caRegs.I2CSTR.bit.RRDY)
       			break;
       	}
        if (i == 1000) {
        	return -1;
        }
        *PRxData = I2caRegs.I2CDRR;               // Load TX buffer

        num--;                                    // Decrement TX byte counter
        PRxData++;
    }
    return 0;
}


/**
  * @brief  Send command to bq27510 through i2c bus
  * @param  cmd : command to be sent to bq27510
  * @retval None
  */
void Write_BQ27510(int cmd)
{
    while (I2caRegs.I2CMDR.bit.STP == 1);

    I2caRegs.I2CCNT = 1;
    I2caRegs.I2CDXR = cmd;                     // Load data to be sent
    SendString("     \r\n");

    I2caRegs.I2CMDR.all = I2C_WRITE_ENABLE;    // Enable data transmitting

    SendString("       \r\n");
}


/**
  * @brief  Send data to bq27510 through i2c bus
  * @param  data : data to be sent to bq27510
  * @retval None
  */
void I2CWriteData(char data)
{
    while (I2caRegs.I2CSTR.bit.BB);            // Check if the bus is busy

    while (I2caRegs.I2CMDR.bit.STP);

    I2caRegs.I2CSAR = 0X55;                    // Slave address
    I2caRegs.I2CDXR = data;                    // Load data

    I2caRegs.I2CMDR.all = 0x67A0;              // Enable I2C
}


/**
  * @brief  SCI Initialization
  * @param  None
  * @retval None
  */
void SCIAInit()
{
    InitSciaGpio();
    /* 1 stop bit,odd-even check none,8 data bits */
    SciaRegs.SCICCR.all = 0x0007;
    SciaRegs.SCICTL1.all = 0x0003;  // Enable TX, RX

#if (CPU_FRQ_60MHZ)
    SciaRegs.SCIHBAUD    = 0x0000;  // baudrate=9600��LSPCLK=15MHz (60 MHz SYSCLK).
    SciaRegs.SCILBAUD    = 0x00C2;
#elif (CPU_FRQ_40MHZ)
    SciaRegs.SCIHBAUD    = 0x0000;  // baudrate=9600��LSPCLK=10MHz (40 MHz SYSCLK).
    SciaRegs.SCILBAUD    = 0x0081;
#endif

    SciaRegs.SCICTL1.all = 0x0023;  // Clear reset status
}


/**
  * @brief  Send character
  * @param  data : byte data sent from serial port
  * @retval None
  */
void SendChar(unsigned char data)
{
    while (SciaRegs.SCICTL2.bit.TXRDY != 1);

    SciaRegs.SCITXBUF = data;
}


/**
  * @brief  Send string
  * @param  msg : string sent form serial port
  * @retval None
  */
void SendString(char * msg)
{
    int i;
    i = 0;

    while (msg[i] != '\0') {
        SendChar(msg[i]);
        i++;
    }
}


/**
  * @brief  Receive character
  * @param  None
  * @retval received character 
  */
char receiveByte()
{
    char c;

    while (SciaRegs.SCIRXST.bit.RXRDY != 1);   // Wait for receiving character

    c = SciaRegs.SCIRXBUF.bit.RXDT;            // Get character
    return c;
}


/**
  * @brief  receiving string over serial port
  * @param  s : buffer to store the received string
  * @retval None
  */
void receivestr(char *s)
{
    int i = 0;

    while (1) {
        while (SciaRegs.SCIRXST.bit.RXRDY != 1); // Wait for receiving character

        s[i] = SciaRegs.SCIRXBUF.bit.RXDT;       // Get character

        if (s[i] == '\r') {
            break;
        } else {
            while (SciaRegs.SCICTL2.bit.TXRDY != 1);

            SciaRegs.SCITXBUF = s[i];
            i++;
        }

    }
}


/**
  * @brief  puts() is used by printf() to display or send a string. This
  *         function determines where printf prints to. For this case it sends
  *         a string out over UART, another option could be to display the
  *         string on an LCD display.
  * @param  s
  * @retval None
  */
void fputs(char *s)
{
    char c;

    /* Loops through each character in string 's' */
    while (c = *s++) {
        SendChar(c);
    }
}


/**
  * @brief  fputc() is used by printf() to display or send a character. This
  *         function determines where printf prints to. For this case it sends
  *         a character out over UART.
  * @param  b
  * @retval None
  */
void fputc(unsigned b)
{
    SendChar(b);
}


/**
  * @brief  Timer initialization
  * @param  None
  * @retval None
  */
void initTimer(void)
{
    CpuTimer0Regs.TPR.bit.TDDR = 59;   // Prescale, 60M/60=1M
    CpuTimer0Regs.TPRH.bit.TDDRH = 0;  
    CpuTimer0Regs.PRD.all = 500000;    // timer 1s
    CpuTimer0Regs.TCR.bit.TRB = 1;     // reload
    CpuTimer0Regs.TCR.bit.TIE = 1;     // enable interrupt
    CpuTimer0Regs.TCR.bit.TSS = 0;     // start counting
}


/**
  * @brief  Timer0 interrupt service routine
  * @param  None
  * @retval None
  */
interrupt void tim0_isr(void)
{

    timerCount++;
    /* Enable future timer0 (PIE Group 1) interrupts */
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;

}

/**
  * @brief  i2c interrupt service routine
  * @param  None
  * @retval None
  */
interrupt void i2c_int1a_isr(void)
{
    Uint16 status;
    status = I2caRegs.I2CISRC.all;

    if (status == 0x05) { // Transmit data ready

    }
}
