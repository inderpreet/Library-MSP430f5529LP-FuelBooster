//*****************************************************************************

//	This example show how to communicate with bq27510 through I2C which
//implemented by gpio.

//*****************************************************************************

/*
******************************************************************************
*                                  INCLUDE FILES
******************************************************************************
*/
#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "utils/uartstdio.h"
#include "inc/tm4c1233h6pm.h"
#include "gpio_i2c.h"
#include "bq27510.h"
#include "driverlib/timer.h"
#include "driverlib/fpu.h"
#include "driverlib/rom.h"
#include "stdlib.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom_map.h"
/*
******************************************************************************
*                                  DEFINITIONS
******************************************************************************
*/
#define	MAXSIZE	20
/*
******************************************************************************
*                                  GLOBAL VARIABLES
******************************************************************************
*/
unsigned char Rxdata[20];
char Rxbuffer[MAXSIZE];
int flag1 = 1;
int flag2 = 1;
char c;
/*
******************************************************************************
*                                  FUNCTION PROTOTYPES
******************************************************************************
*/
int LM4F120_bq27510_read(unsigned char cmd, unsigned int bytes);

int LM4F120_bq27510_write(unsigned char cmd, unsigned char data);

unsigned int transBytes2Int(unsigned char msb, unsigned char lsb);

/*
******************************************************************************
*                                  FUNCTION DEFINITIONS
******************************************************************************
*/

/**
  * @brief  The interrupt handler for the first timer interrupt
  * @param
  * @retval None
  */
void Timer0IntHandler(void)
{
    //
    // Clear the timer interrupt.
    //
    ROM_TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    flag1 = 1;

    ROM_IntMasterEnable();

}

/**
  * @brief  The interrupt handler for the  timer1 interrupt
  * @param
  * @retval None
  */
void Timer1IntHandler(void)
{
    //
    // Clear the timer interrupt.
    //
    ROM_TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);

    flag2 = 1;

    ROM_IntMasterEnable();

}

//*****************************************************************************
//
// This function sets up UART0 to be used for a console to display information
// as the example is running.
//
//*****************************************************************************
/**
  * @brief  Initialize the UART for 115200 baud
  * @param
  * @retval None
  */
void InitConsole(void)
{
    //
    // Enable GPIO port A which is used for UART0 pins.
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    //
    // Configure the pin muxing for UART0 functions on port A0 and A1.
    //
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);

    //
    // Select the alternate (UART) function for these pins.
    //
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    //
    // Initialize the UART for console I/O.
    //
    UARTStdioConfig(0, 115200, MAP_SysCtlClockGet());
}

/**
  * @brief  Initialize the Timer0
  * @param  int16_t cycle
  * @retval None
  */
void InitTimer0(int16_t cycle)
{
	//
	// Enable the peripherals used by this example.
	//
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);

	//
	// Enable processor interrupts.
	//
	ROM_IntMasterEnable();

	//
	// Configure the two 32-bit periodic timers.
	//
	ROM_TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
	ROM_TimerLoadSet(TIMER0_BASE, TIMER_A, ROM_SysCtlClockGet()*cycle);

	//
	// Setup the interrupts for the timer timeouts.
	//
	ROM_IntEnable(INT_TIMER0A);
	ROM_TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

	//
	// Enable the timers.
	//
	ROM_TimerEnable(TIMER0_BASE, TIMER_A);

}

/**
  * @brief  Initialize the Timer1
  * @param  int16_t cycle
  * @retval None
  */
void InitTimer1(int16_t cycle)
{
	//
	// Enable the peripherals used by this example.
	//
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);

	//
	// Enable processor interrupts.
	//
	ROM_IntMasterEnable();

	//
	// Configure the two 32-bit periodic timers.
	//
	ROM_TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);
	ROM_TimerLoadSet(TIMER1_BASE, TIMER_A, ROM_SysCtlClockGet()*cycle);

	//
	// Setup the interrupts for the timer timeouts.
	//
	ROM_IntEnable(INT_TIMER1A);
	ROM_TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);

	//
	// Enable the timers.
	//
	ROM_TimerEnable(TIMER1_BASE, TIMER_A);

}

/**
  * @brief  Main function
  * @param  None
  * @retval None
  */
void main(void)
{

	int16_t  interval;
	int temperature,voltage;
	int valid_data = 0;
	signed int  AverageCurrent;
	unsigned int  RemainingCapacity;
	unsigned int  soc;                          // Stores State of Charge
	unsigned int  dcap;                         // Stores Design Capacity
	int temp;

	ROM_FPULazyStackingEnable();
    //
    // Set the clocking to run directly from the external crystal/oscillator.
    //
    SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN |
                   SYSCTL_XTAL_16MHZ);


    //
    //  Enable GPIOB and GPIOF.
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

    GPIO_PORTB_DIR_R |= SCL | SDA;
    GPIO_PORTB_DEN_R |= SCL | SDA;

    GPIO_PORTF_DIR_R |= 0x08;
    GPIO_PORTF_DEN_R |= 0x08;

    //
    // Set up the serial console to use for displaying messages. 
    //
    InitConsole();

    //Test by LiuXin, should be removed
    //SDA_1;
    //GPIO_PORTB_DIR_R &= ~SDA;
    //   UARTprintf("GPIO_PB_DIR\r\n");
    //    while(1);
    //End

    UARTprintf("******************************************\r\n");
    UARTprintf("This is a battery demo !				  \r\n");
    UARTprintf("Press:									  \r\n");
    UARTprintf("1. To see the battery main parameter 	  \r\n");
    UARTprintf("2. To see the battery State of charge!	  \r\n");
    UARTprintf("******************************************\r\n");
    UARTprintf("\r\n");
    UARTprintf("\r\n");
    UARTprintf("\r\n");

    c = UARTgetc();

    while(1)
    {

    	if(c == '1')
    	{
    		//
    		// Init timer0,the cycle is 5s;
    		//
    		InitTimer0(5);

    		//
    		//First reading of numerical instability,discard
    		//
    		LM4F120_bq27510_read(bq27510CMD_TEMP_LSB, 2);
    		temperature = (transBytes2Int(Rxdata[1], Rxdata[0]))/10 - 273;

    		while(1)
    		{
    			valid_data = 1;
    			//
                //Read temperature  again(units = 0.1K)
                //
    			if(!LM4F120_bq27510_read(bq27510CMD_TEMP_LSB, 2)) {
					//
					//convert K to ��
					//
					temperature = (transBytes2Int(Rxdata[1], Rxdata[0]))/10 - 273;
    			} else {
    				valid_data = 0;
    			}

    			//
                //Read voltage (units = mV)
                //
    			if(!LM4F120_bq27510_read(bq27510CMD_VOLT_LSB, 2)) {
    				voltage = transBytes2Int(Rxdata[1], Rxdata[0]);
    			} else {
    				valid_data = 0;
    			}

    			//
                //Read AverageCurrent (units = mA)
                //
    			if(!LM4F120_bq27510_read(bq27510CMD_AI_LSB, 2)) {
					//
					//	the AverageCurrent is a 16bit value
					//	if it > 0x7fff, it real value is temp - 0xffff
					//
					temp = transBytes2Int(Rxdata[1], Rxdata[0]);
					if(temp > 0x7fff)
						AverageCurrent = temp - 0xFFFF;
					else
						AverageCurrent = temp;
    			} else {
    				valid_data = 0;
    			}

    			//
                //Read state of charge (units = %)
                //
    			if(!LM4F120_bq27510_read(bq27510CMD_SOC_LSB, 2)) {
    				soc = transBytes2Int(Rxdata[1], Rxdata[0]);
    			} else {
    				valid_data = 0;
    			}

				//
    			//Read DesignCapacity (units = mAH)
				//
    			if(!LM4F120_bq27510_read(bq27510CMD_DCAP_LSB, 2)) {
    				dcap = transBytes2Int(Rxdata[1], Rxdata[0]);
    			} else {
    				valid_data = 0;
    			}

				//
    			//Read RemainingCapacity (units = mAH)
				//
    			if(!LM4F120_bq27510_read(bq27510CMD_RM_LSB, 2)) {
    				RemainingCapacity = transBytes2Int(Rxdata[1], Rxdata[0]);
    			} else {
    				valid_data = 0;
    			}


    			if(flag1 == 1)
    			{
    				//
    				// Clear the console
    				//
    				UARTprintf("\033[2J");
    				UARTprintf("\033[H");
    				flag1 = 0;

    				if(valid_data) {
						LM4F120_bq27510_read(bq27510CMD_AI_LSB, 2);
						//
						//	the AverageCurrent is a 16bit value
						//	if it > 0x7fff, it real value is temp - 0xffff
						//
						temp = transBytes2Int(Rxdata[1], Rxdata[0]);
						if(temp > 0x7fff)
							AverageCurrent = temp - 0xFFFF;
						else
							AverageCurrent = temp;
						if(AverageCurrent > 0)
						{
							UARTprintf("The battery is charging!\r\n");
						}
						else
						{
							UARTprintf("The battery is discharging!\r\n");
						}

						UARTprintf("Current Temperature  :%d��\r\n", temperature);
						UARTprintf("Current Voltage  :%dmV\r\n", voltage);
						UARTprintf("AverageCurrent  :%dmA\r\n", AverageCurrent);
						UARTprintf("State of Charge :%d%%\r\n", soc);
						UARTprintf("DesignCapacity :%dmAH\r\n", dcap);
						UARTprintf("RemainingCapacity :%dmAH\r\n", RemainingCapacity);
    				} else {
    					UARTprintf("There is no battery or the battery's capacity is too low\n\r");
    					UARTprintf("Please plugin a battery or charge the battery\n\r");
    				}
    			}
    		}
    	}

    	if(c == '2')
    	{
    		UARTprintf("Please set the show time interval(units = s)\r\n");
    		UARTgets(Rxbuffer, MAXSIZE);
    		//
    		//convert string to int
    		//
    		interval = atoi(Rxbuffer);
    		//
    		//init timer1
    		//
    		InitTimer1(interval);

    		//
    		//First reading of numerical instability,discard
    		//
    		LM4F120_bq27510_read(bq27510CMD_SOC_LSB, 2);
    		soc = transBytes2Int(Rxdata[1], Rxdata[0]);

    		while(1)
    		{
    			valid_data = 1;

				//
    			//Read state of charge (units = %)
				//
    			if(!LM4F120_bq27510_read(bq27510CMD_SOC_LSB, 2)) {
    				soc = transBytes2Int(Rxdata[1], Rxdata[0]);
    			} else {
    				valid_data = 0;
    			}

    			if(flag2 == 1)
    			{
    				flag2 = 0;

    				if(valid_data) {
    					UARTprintf("State of Charge :%d%%\r\n", soc);
    				} else {
    					//
    					// Clear the console
    					//
    					UARTprintf("\033[2J");
    					UARTprintf("\033[H");
    					UARTprintf("There is no battery or the battery's capacity is too low\n\r");
    					UARTprintf("Please plugin a battery or charge the battery\n\r");
    				}
    			}
    		}
    	}
    }
}

/**
  * @brief  Translate two bytes into an integer
  * @param
  * @retval The calculation results
  */
unsigned int transBytes2Int(unsigned char msb, unsigned char lsb)
{
  unsigned int tmp;

  tmp = ((msb << 8) & 0xFF00);
  return ((unsigned int)(tmp + lsb) & 0x0000FFFF);
}
/**
  * @brief  Receive data from bq27510 through i2c bus
  * @param
  * @retval  0 : read successfully
  *         -1 : read failed
  */
int LM4F120_bq27510_read(unsigned char cmd, unsigned int bytes)
{
  unsigned char tx[1];
  int ret;

  tx[0] = cmd;
  ret = LM4F120_SWI2CMST_writeBlock(SLAVE_ADDRESS, 1, 1, tx);
  if(ret < 0)
	  return ret;

  ret = LM4F120_SWI2CMST_readBlock(SLAVE_ADDRESS, bytes, Rxdata);
  if(ret < 0)
	  return ret;

  return 0;
}
/**
  * @brief  Send data to bq27510 through i2c bus
  * @param
  * @retval  0 : read successfully
  *         -1 : read failed
  */
int LM4F120_bq27510_write(unsigned char cmd, unsigned char data)
{
  unsigned char tx[2];
  int ret;

  tx[0] = cmd;
  tx[1] = data;

  ret = LM4F120_SWI2CMST_writeBlock(SLAVE_ADDRESS, 2, 0, tx);
  if(ret < 0)
	  return ret;

  I2CDELAY(500);

  return 0;
}
