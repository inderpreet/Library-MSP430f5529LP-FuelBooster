//###########################################################################
//
// FILE:   f2802x_examples/FuelTank_BoostPack/printf.c
//
// TITLE:  printf function retarget
//
//###########################################################################

/*
******************************************************************************
*                                  INCLUDE FILES
******************************************************************************
*/
#include "stdarg.h"


/*
******************************************************************************
*                                  FUNCTION PROTOTYPES
******************************************************************************
*/
extern void fputc(unsigned);
extern void fputs(char *);


/*
******************************************************************************
*                                  FUNCTION DEFINITIONS
******************************************************************************
*/

/**
  * @brief  Convert int to string.For example,convert 12345 to "12345"
  * @param  
  * @retval None
  */
void IntToString(int temp, char *pchar)
{
    char ch, *p = pchar;
    int a = temp;

    if (temp < 0) {
        temp = 0 - temp;
    }

    while (temp != 0) {
        *pchar++ = (char)(temp % 10 + 0x30);
        temp /= 10;
    }

    if (a < 0) {
        *pchar++ = '-';
    }

    *pchar-- = '\0';

    while (pchar > p) {
        ch = *p;
        *p++ = *pchar;
        *pchar-- = ch;
    }
}

void Vs_Printf(char *s, char *format, va_list arg)
{
    char *pchar;
    char *temp;

    for (pchar = format; *pchar; pchar++) {
        if (*pchar != '%') {
            *s++ = *pchar;
            continue;
        }

        switch (*++pchar) {
        case 'd'   : {
            IntToString(va_arg(arg, int), s);

            while (*s++);

            *--s = '0';
            break;
        }

        case 's'   : {
            temp = va_arg(arg, char *);

            while (*s++ = *temp++);

            *--s = '0';
            break;
        }

        case 'c'   : {
            *s++ = va_arg(arg, char);
            break;
        }

        default       :
            break;
        }
    }

    *s = '\0';
}

void printf(char *fmt, ...)
{

    va_list ap;
    char string[256];
    va_start(ap, fmt);
    Vs_Printf(string, fmt, ap);
    fputs(string);
    va_end(ap);
}
